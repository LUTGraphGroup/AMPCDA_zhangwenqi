# AMPCDA

AMPCDA：Prediction of circRNA-disease associations by utilizing attention mechanisms on metapaths

Run main.py to get prediction results. 