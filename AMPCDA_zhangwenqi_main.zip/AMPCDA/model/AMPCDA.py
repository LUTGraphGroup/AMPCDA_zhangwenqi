import torch
import torch.nn as nn
import torch.nn.functional as F
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
from utils.pathvec import *
import utils.readPickle as rdp
from utils.index import *
from utils.concat import *
from model.encoder import *
#from sklearn.metrics.pairwise import cosine_similarity


# 定义自注意力层
class SelfAttention(nn.Module):
    def __init__(self, input_size, num_heads, dropout=0.1):
        super(SelfAttention, self).__init__()
        self.num_heads = num_heads
        self.head_size = input_size // num_heads

        self.query = nn.Linear(input_size, input_size)
        self.key = nn.Linear(input_size, input_size)
        self.value = nn.Linear(input_size, input_size)

        def init_weights(m):
            if type(m) == nn.Linear:
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif type(m) == nn.Conv2d:
                nn.init.uniform_(m.weight)

        self.dropout = nn.Dropout(dropout)
        self.query.apply(init_weights)
        self.key.apply(init_weights)
        self.value.apply(init_weights)
    def forward(self, x):
        batch_size, seq_len, input_size = x.size()

        # 将输入特征拆分成多个头并线性映射
        q = self.query(x).view(batch_size, seq_len, self.num_heads, self.head_size)
        k = self.key(x).view(batch_size, seq_len, self.num_heads, self.head_size)
        v = self.value(x).view(batch_size, seq_len, self.num_heads, self.head_size)

        # 调整维度以进行自注意力计算
        q = q.transpose(1, 2)  # (batch_size, num_heads, seq_len, head_size)
        k = k.transpose(1, 2)  # (batch_size, num_heads, seq_len, head_size)
        v = v.transpose(1, 2)  # (batch_size, num_heads, seq_len, head_size)

        # 计算注意力分数并应用缩放点积注意力
        attn_scores = torch.matmul(q, k.transpose(-2, -1))  # (batch_size, num_heads, seq_len, seq_len)
        attn_scores = attn_scores / (self.head_size ** 0.5)
        attn_probs = F.softmax(attn_scores, dim=-1)

        # 使用注意力权重对值进行加权聚合
        attn_output = torch.matmul(self.dropout(attn_probs), v)  # (batch_size, num_heads, seq_len, head_size)

        # 拼接多头输出并进行线性变换
        attn_output = attn_output.transpose(1, 2).contiguous()  # (batch_size, seq_len, num_heads, head_size)
        attn_output = attn_output.view(batch_size, seq_len, -1)  # (batch_size, seq_len, input_size)

        return attn_output


def IdenticalPattern(meta_paths, node_features):
    num_paths = len(meta_paths)
    num_features = len(node_features[0])
    node_features_tensor = torch.tensor(node_features, dtype=torch.float32)

    dataset = TensorDataset(node_features_tensor)
    dataloader = DataLoader(dataset, batch_size=num_paths, shuffle=False)

    model = IdenticalPatternEncoder(input_size=num_features, hidden_size=128, num_heads=8, num_layers=4)
    model.train()

    with torch.no_grad():
        aggregated_features = []
        for batch in dataloader:
            node_features_batch = batch[0]
            aggregated_feature = model(node_features_batch)
            aggregated_features.append(aggregated_feature)

    aggregated_features = torch.cat(aggregated_features, dim=0).numpy()
    return aggregated_features


def DivergentPattern(node_features_list, num_heads=4):
    self_attention_layer = SelfAttention(input_size=len(node_features_list[0][0]), num_heads=num_heads)
    aggregated_features = []

    for node_features in node_features_list:
        tensor_features = [torch.tensor(features) for features in node_features]
        input_tensor = torch.stack(tensor_features, dim=0).unsqueeze(0)

        weighted_features = self_attention_layer(input_tensor)

        attention_weights = F.softmax(weighted_features, dim=2)
        aggregated_feature =attention_weights * input_tensor
        aggregated_features.append(aggregated_feature.squeeze(0))

    aggregated_tensor = torch.stack(aggregated_features, dim=0)

    final_aggregated_feature = torch.mean(aggregated_tensor, dim=0)
    return final_aggregated_feature


circ_hidden, disease_hidden, mir_hidden = compute_node_features()
c_c = rdp.c_c_pairs
cindex1_vector, cindex2_vector = c_c_hidden_vectors(c_c, circ_hidden)
c_d_c = rdp.c_d_c_pairs
cindex1_vector, dindex1_vector, cindex2_vector = c_d_c_hidden_vectors(c_d_c, circ_hidden, disease_hidden)
c_d_d_c = rdp.c_d_d_c_pairs
cindex1_vector, dindex1_vector, dindex2_vector, cindex2_vector = c_d_d_c_hidden_vectors(c_d_d_c, circ_hidden, disease_hidden)
c_m_c = rdp.c_m_c_pairs
cindex1_vector, mindex1_vector, cindex2_vector = c_m_c_hidden_vectors(c_m_c, circ_hidden, mir_hidden)
d_d = rdp.d_d_pairs
dindex1_vector, dindex2_vector = d_d_hidden_vectors(d_d, disease_hidden)
d_c_c_d = rdp.d_c_c_d_pairs
dindex1_vector, cindex1_vector, cindex2_vector, dindex2_vector = d_c_c_d_hidden_vectors(d_c_c_d, circ_hidden, disease_hidden)
d_c_m_c_d = rdp.d_c_m_c_d_pairs
dindex1_vector, cindex1_vector, mindex1_vector, cindex2_vector, dindex2_vector = d_c_m_c_d_hidden_vectors(d_c_m_c_d, circ_hidden, disease_hidden, mir_hidden)

c_c_mp_vec = cc_mp_vec(c_c, circ_hidden)
c_d_c_mp_vec = cdc_mp_vec(c_d_c, circ_hidden, disease_hidden)
c_d_d_c_mp_vec = cddc_mp_vec(c_d_d_c, circ_hidden, disease_hidden)
c_m_c_mp_vec = cmc_mp_vec(c_m_c, circ_hidden, mir_hidden)
d_d_mp_vec = dd_mp_vec(d_d, disease_hidden)
d_c_c_d_mp_vec = dccd_mp_vec(d_c_c_d, circ_hidden, disease_hidden)
d_c_m_c_d_mp_vec = dcmcd_mp_vec(d_c_m_c_d, circ_hidden, disease_hidden, mir_hidden)

meta_paths_cc = {"c_c": c_c_mp_vec}
meta_paths_cdc = {"c_d_c": c_d_c_mp_vec}
meta_paths_cddc = {"c_d_d_c": c_d_d_c_mp_vec}
meta_paths_cmc = {"c_m_c": c_m_c_mp_vec}
meta_paths_dd = {"d_d": d_d_mp_vec}
meta_paths_dccd = {"d_c_c_d": d_c_c_d_mp_vec}
meta_paths_dcmcd = {"d_c_m_c_d": d_c_m_c_d_mp_vec}

aggregated_features_cc = IdenticalPattern(meta_paths_cc, circ_hidden)
aggregated_features_cdc = IdenticalPattern(meta_paths_cdc, circ_hidden)
aggregated_features_cddc = IdenticalPattern(meta_paths_cddc, circ_hidden)
aggregated_features_cmc = IdenticalPattern(meta_paths_cdc, circ_hidden)
aggregated_features_dd = IdenticalPattern(meta_paths_dd, disease_hidden)
aggregated_features_dccd = IdenticalPattern(meta_paths_dccd, disease_hidden)
aggregated_features_dcmcd = IdenticalPattern(meta_paths_dcmcd, disease_hidden)


circ_node_features = [aggregated_features_cc, aggregated_features_cdc, aggregated_features_cddc,
                      aggregated_features_cmc]
disease_node_features = [aggregated_features_dd, aggregated_features_dccd, aggregated_features_dcmcd]

circ_aggregated2_ts = DivergentPattern(circ_node_features)
disease_aggregated2_ts = DivergentPattern(disease_node_features)