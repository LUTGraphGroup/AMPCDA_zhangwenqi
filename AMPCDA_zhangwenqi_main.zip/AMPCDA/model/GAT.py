import math
import torch
import torch.nn as nn
from model.GATlayer import GATConv
from utils.utils import train_features_choose, test_features_choose, build_heterograph
from model.SelfAttention import *

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class MLP(nn.Module):
    def __init__(self, embedding_size, drop_rate):
        super(MLP, self).__init__()
        self.embedding_size = embedding_size  # 2807
        self.drop_rate = drop_rate

        def init_weights(m):
            if type(m) == nn.Linear:
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif type(m) == nn.Conv2d:
                nn.init.uniform_(m.weight)

        hidden_sizes = [self.embedding_size // 2, self.embedding_size // 4, self.embedding_size // 8,
                        self.embedding_size // 16]

        layers = []
        input_size = self.embedding_size

        for size in hidden_sizes:
            layers.append(nn.Linear(input_size, size))
            layers.append(nn.LeakyReLU())
            layers.append(nn.Dropout(self.drop_rate))
            input_size = size

        layers.append(nn.Linear(input_size, 1, bias=False))
        layers.append(nn.Sigmoid())

        self.mlp_prediction = nn.Sequential(*layers).to(device)
        self.mlp_prediction.apply(init_weights)

    def forward(self, rd_features_embedding):
        predict_result = self.mlp_prediction(rd_features_embedding)
        return predict_result

class GAT(nn.Module):
    def __init__(self, in_circfeat_size, in_disfeat_size,  outfeature_size, heads, drop_rate,
                 negative_slope,
                 features_embedding_size, negative_times):
        super(GAT, self).__init__()
        self.in_circfeat_size = in_circfeat_size  # 3077
        self.in_disfeat_size = in_disfeat_size  # 313

        self.outfeature_size = outfeature_size  # 128
        self.heads = heads  # 8
        self.drop_rate = drop_rate  # 0.1
        self.negative_slope = negative_slope  # 0.3

        self.features_embedding_size = features_embedding_size  # 2807

        self.negative_times = negative_times
        self.tanh =  nn.Tanh()
        self.att_layer = GATConv(256, 128, self.heads, self.drop_rate,
                                 self.drop_rate, self.negative_slope)

        self.W_rna1 = nn.Parameter(torch.zeros(size=(self.in_circfeat_size, self.outfeature_size)))
        self.W_dis1 = nn.Parameter(torch.zeros(size=(self.in_disfeat_size, self.outfeature_size)))


        nn.init.xavier_uniform_(self.W_rna1.data, gain=1.414)
        nn.init.xavier_uniform_(self.W_dis1.data, gain=1.414)

        self.mlp_prediction = MLP(self.features_embedding_size, self.drop_rate)

        self.init_weights()

    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Conv2d):
                nn.init.uniform_(m.weight)

    def forward(self, gcd, circ_feature_tensor, dis_feature_tensor,similarity_Graph_c,similarity_Graph_d,
                rel_matrix, train_model):

        circ_circ_f1 = circ_feature_tensor.mm(self.W_rna1)
        dis_dis_f1 = dis_feature_tensor.mm(self.W_dis1)
        split_tensors = torch.split(similarity_Graph_c, split_size_or_sections=128, dim=1)
        # 将切分后的小张量分别存储在变量中
        aggregated_features_cc = split_tensors[0].tolist()
        aggregated_features_cdc = split_tensors[1].tolist()
        aggregated_features_cddc = split_tensors[2].tolist()
        aggregated_features_cmc = split_tensors[3].tolist()
        circ_node_features = [aggregated_features_cc, aggregated_features_cdc, aggregated_features_cddc,
                      aggregated_features_cmc]

        split_tensors = torch.split(similarity_Graph_d, split_size_or_sections=128, dim=1)
        # 将切分后的小张量分别存储在变量中
        aggregated_features_dd = split_tensors[0].tolist()
        aggregated_features_dccd = split_tensors[1].tolist()
        aggregated_features_dcmcd = split_tensors[2].tolist()
        disease_node_features = [aggregated_features_dd, aggregated_features_dccd, aggregated_features_dcmcd]

        similarity_Graph_c=DivergentPattern(circ_node_features)
        similarity_Graph_d=DivergentPattern(disease_node_features)

        circ_circ_f1 = torch.cat((circ_circ_f1, similarity_Graph_c.to(device)), dim=1)
        dis_dis_f1 = torch.cat((dis_dis_f1, similarity_Graph_d.to(device)), dim=1)

        h_c_d_feature1 = torch.cat((circ_circ_f1, dis_dis_f1), dim=0)

        rcd = self.att_layer(gcd, h_c_d_feature1)
        h_c_d_feature2 = rcd.view(761, 1, self.heads, -1)
        cnn_output = h_c_d_feature2.view(761, self.heads * self.outfeature_size)

        if train_model:
            train_features_inputs, train_lable = train_features_choose(rel_matrix, cnn_output, self.negative_times)
            train_mlp_result = self.mlp_prediction(train_features_inputs)
            return train_mlp_result, train_lable
        else:
            test_features_inputs, test_lable = test_features_choose(rel_matrix, cnn_output)
            test_mlp_result = self.mlp_prediction(test_features_inputs)
            return test_mlp_result, test_lable