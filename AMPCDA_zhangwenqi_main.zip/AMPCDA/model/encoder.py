import torch
import torch.nn as nn

class IdenticalPatternEncoder(nn.Module):
    def __init__(self, input_size, hidden_size, num_heads, num_layers):
        super(IdenticalPatternEncoder, self).__init__()
        self.embedding = nn.Linear(input_size, hidden_size)
        self.encoder_layers = nn.ModuleList([
            IdenticalPatternEncoderLayer(hidden_size, num_heads) for _ in range(num_layers)
        ])

    def forward(self, x):
        x = self.embedding(x)
        for layer in self.encoder_layers:
            x = layer(x)
        return x

class IdenticalPatternEncoderLayer(nn.Module):
    def __init__(self, hidden_size, num_heads):
        super(IdenticalPatternEncoderLayer, self).__init__()
        self.attention = nn.MultiheadAttention(hidden_size, num_heads)
        self.layer_norm1 = nn.LayerNorm(hidden_size)
        self.feed_forward = nn.Sequential(
            nn.Linear(hidden_size, 4 * hidden_size),
            nn.ReLU(),
            nn.Linear(4 * hidden_size, hidden_size)
        )
        self.layer_norm2 = nn.LayerNorm(hidden_size)

    def forward(self, x):
        attended, _ = self.attention(x, x, x)
        x = x + attended
        x = self.layer_norm1(x)
        feed_forward_output = self.feed_forward(x)
        x = x + feed_forward_output
        x = self.layer_norm2(x)
        return x