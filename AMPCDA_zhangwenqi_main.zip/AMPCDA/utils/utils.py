import random

import numpy as np
import torch
import dgl
import matplotlib.pyplot as plt
import warnings

warnings.filterwarnings("ignore", message="DGLGraph\.__len__")
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

def build_heterograph(circrna_disease_matrix, circSimi, disSimi):

    # 求出相似矩阵平均值，大于平均值，认为有连边
    # rna 0.4055
    # mean_Similarity_circRNA = np.mean(circSimi)
    # 3077*3077
    matAdj_circ = np.where(circSimi > 0.5, 1, 0)

    # dis 0.0903
    # mean_Similarity_disease = np.mean(disSimi)
    # 313*313
    matAdj_dis = np.where(disSimi > 0.5, 1, 0)

    # Heterogeneous adjacency matrix
    # np.hstack()：按水平方向（列顺序）堆叠数组构成一个新的数组堆叠的数组需要具有相同的维度
    # 3077*3390
    h_adjmat_1 = np.hstack((matAdj_circ, circrna_disease_matrix))  #3077*3077  3077*313
    # 313*3390
    h_adjmat_2 = np.hstack((circrna_disease_matrix.transpose(), matAdj_dis))  #313*3077 313*313
    # np.vstack()：按垂直方向（行顺序）堆叠数组构成一个新的数组堆叠的数组需要具有相同的维度
    # 3390*3390
    Heterogeneous1 = np.vstack((h_adjmat_1, h_adjmat_2))
    # heterograph
    gcd = dgl.heterograph(
        data_dict={
            # Heterogeneous.nonzero()返回非0元素索引
            ('circRNA_disease', 'interaction', 'circRNA_disease'): Heterogeneous1.nonzero()},
        num_nodes_dict={
            'circRNA_disease': 761
        })

    return gcd



def train_features_choose(rel_adj_mat, features_embedding, negative_sample_times):#3077*313   4237*2807      1
    rna_nums = rel_adj_mat.size()[0]
    features_embedding_rna = features_embedding[0:rna_nums, :]
    features_embedding_dis = features_embedding[rna_nums:features_embedding.size()[0], :]
    train_features_input, train_lable = [], []
    positive_index_tuple = torch.where(rel_adj_mat == 1)
    positive_index_list = list(zip(positive_index_tuple[0], positive_index_tuple[1]))
    for (r, d) in positive_index_list:
        train_features_input.append((features_embedding_rna[r, :] * features_embedding_dis[d, :]).unsqueeze(0))
        train_lable.append(1)
        negative_colindex_list = []

        for i in range(negative_sample_times):
            j = np.random.randint(rel_adj_mat.size()[1])
            while (r, j) in positive_index_list:
                j = np.random.randint(rel_adj_mat.size()[1])
            negative_colindex_list.append(j)
        for nums_1 in range(len(negative_colindex_list)):
            train_features_input.append(
                (features_embedding_rna[r, :] * features_embedding_dis[negative_colindex_list[nums_1], :]).unsqueeze(0))
        for nums_2 in range(len(negative_colindex_list)):
            train_lable.append(0)
    train_features_input = torch.cat(train_features_input, dim=0)
    train_lable = torch.FloatTensor(np.array(train_lable)).unsqueeze(1)
    return train_features_input.to(device), train_lable.to(device)


def test_features_choose(rel_adj_mat, features_embedding):#3077*313   4237*2807
    # Get the number of RNA and distance nodes
    rna_nums, dis_nums = rel_adj_mat.size()[0], rel_adj_mat.size()[1]
    # Get the features embedding of RNA nodes
    features_embedding_rna = features_embedding[0:rna_nums, :]
    # Get the features embedding of distance nodes
    features_embedding_dis = features_embedding[rna_nums:features_embedding.size()[0], :]
    # Create a list to store the test features and labels
    test_features_input, test_lable = [], []

    # Iterate over the RNA nodes
    for i in range(rna_nums):
        # Iterate over the distance nodes
        for j in range(dis_nums):
            # Append the features of the RNA node and distance node to the list
            test_features_input.append((features_embedding_rna[i, :] * features_embedding_dis[j, :]).unsqueeze(0))
            # Append the label of the RNA node and distance node to the list
            test_lable.append(rel_adj_mat[i, j])

    # Convert the list to tensor
    test_features_input = torch.cat(test_features_input, dim=0)
    # Convert the list to tensor
    test_lable = torch.FloatTensor(test_lable).cpu().unsqueeze(1)
    # Return the test features and labels
    return test_features_input.to(device), test_lable.to(device)



def sort_matrix(score_matrix, interact_matrix):

    sort_index = np.argsort(-score_matrix, axis=0)  # 沿着行向下(每列)的元素进行排序,从大到小排列
    score_sorted = np.zeros(score_matrix.shape)
    y_sorted = np.zeros(interact_matrix.shape)
    for i in range(interact_matrix.shape[1]):
        # score_sorted 的每一列都是 interact_matrix 对应列的从大到小排列的值。
        score_sorted[:, i] = score_matrix[:, i][sort_index[:, i]]
        # y_sorted 的每一列都是 interact_matrix 对应列的从大到小排列的值。
        y_sorted[:, i] = interact_matrix[:, i][sort_index[:, i]]
    return y_sorted, score_sorted