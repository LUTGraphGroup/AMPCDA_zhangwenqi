import pandas as pd
import numpy as np
from model.AMPCDA import *

circd = pd.read_excel('E:/g/data/raw/true_labels.xlsx', index_col=0)
circd = circd.values


def circ_gaussian(matrix, sigma):
    num_rows = matrix.shape[0]
    circ_gaussian = np.zeros((num_rows, num_rows))

    for i in range(num_rows):
        for j in range(i, num_rows):
            x = matrix[i]
            y = matrix[j]
            similarity = np.exp(-np.linalg.norm(x - y)**2 / (2 * sigma**2))

            # 对称地填充相似性矩阵
            circ_gaussian[i, j] = similarity
            circ_gaussian[j, i] = similarity

    return circ_gaussian



def disease_gaussian(matrix, sigma):
    num_rows = matrix.shape[1]
    disease_gaussian = np.zeros((num_rows, num_rows))

    for i in range(num_rows):
        for j in range(i, num_rows):
            x = matrix[i]
            y = matrix[j]
            similarity = np.exp(-np.linalg.norm(x - y)**2 / (2 * sigma**2))

            # 对称地填充相似性矩阵
            disease_gaussian[i, j] = similarity
            disease_gaussian[j, i] = similarity

    return disease_gaussian



def circ_cosine(matrix):
    # 计算矩阵每行的范数
    row_norms = np.linalg.norm(matrix, axis=1, keepdims=True)

    # 计算矩阵的点积
    dot_product = np.dot(matrix, matrix.T)

    # 计算余弦相似性矩阵
    cosine_sim_matrix = dot_product / (row_norms * row_norms.T)
    circ_cosine = np.nan_to_num(cosine_sim_matrix)

    return circ_cosine


def disease_cosine(matrix):
    # 计算矩阵每行的范数
    row_norms = np.linalg.norm(matrix, axis=0, keepdims=True)

    # 计算矩阵的点积
    dot_product = np.dot(matrix.T, matrix)

    # 计算余弦相似性矩阵
    cosine_sim_matrix = dot_product / (row_norms.T * row_norms)
    disease_cosine = np.nan_to_num(cosine_sim_matrix)

    return disease_cosine


circd = pd.read_excel('E:/g/data/raw/true_labels.xlsx', index_col=0)
circd = circd.values
matrix = circd
sigma = 1.0