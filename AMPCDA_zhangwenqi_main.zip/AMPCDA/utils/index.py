import pickle
import numpy as np
import utils.readPickle as rdp
from utils.initial import *


def c_c_hidden_vectors(c_c, circ_hidden):
    cindex1 = c_c[:, 0]
    cindex2 = c_c[:, 1]
    cindex1_vector = circ_hidden[cindex1]
    cindex2_vector = circ_hidden[cindex2]

    return cindex1_vector, cindex2_vector


def c_d_c_hidden_vectors(c_d_c, circ_hidden, disease_hidden):
    cindex1 = c_d_c[:, 0]
    dindex1 = c_d_c[:, 1] - 661
    cindex2 = c_d_c[:, 2]
    cindex1_vector = circ_hidden[cindex1]
    dindex1_vector = disease_hidden[dindex1]
    cindex2_vector = circ_hidden[cindex2]

    return cindex1_vector, dindex1_vector, cindex2_vector


def c_d_d_c_hidden_vectors(c_d_d_c, circ_hidden, disease_hidden):
    cindex1 = c_d_d_c[:, 0]
    dindex1 = c_d_d_c[:, 1] - 661
    dindex2 = c_d_d_c[:, 2] - 661
    cindex2 = c_d_d_c[:, 3]
    cindex1_vector = circ_hidden[cindex1]
    dindex1_vector = disease_hidden[dindex1]
    dindex2_vector = disease_hidden[dindex2]
    cindex2_vector = circ_hidden[cindex2]

    return cindex1_vector, dindex1_vector, dindex2_vector, cindex2_vector


def c_m_c_hidden_vectors(c_m_c, circ_hidden, mir_hidden):
    cindex1 = c_m_c[:, 0]
    mindex1 = c_m_c[:, 1] - 761
    cindex2 = c_m_c[:, 2]
    cindex1_vector = circ_hidden[cindex1]
    mindex1_vector = mir_hidden[mindex1]
    cindex2_vector = circ_hidden[cindex2]

    return cindex1_vector, mindex1_vector, cindex2_vector


def d_d_hidden_vectors(d_d, disease_hidden):
    dindex1 = d_d[:, 0] - 661
    dindex2 = d_d[:, 1] - 661
    dindex1_vector = disease_hidden[dindex1]
    dindex2_vector = disease_hidden[dindex2]

    return dindex1_vector, dindex2_vector


def d_c_c_d_hidden_vectors(d_c_c_d, circ_hidden, disease_hidden):
    dindex1 = d_c_c_d[:, 0] - 661
    cindex1 = d_c_c_d[:, 1]
    cindex2 = d_c_c_d[:, 2]
    dindex2 = d_c_c_d[:, 3] - 661
    dindex1_vector = disease_hidden[dindex1]
    cindex1_vector = circ_hidden[cindex1]
    cindex2_vector = circ_hidden[cindex2]
    dindex2_vector = disease_hidden[dindex2]

    return dindex1_vector, cindex1_vector, cindex2_vector, dindex2_vector


def d_c_m_c_d_hidden_vectors(d_c_m_c_d, circ_hidden, disease_hidden, mir_hidden):
    dindex1 = d_c_m_c_d[:, 0] - 661
    cindex1 = d_c_m_c_d[:, 1]
    mindex1 = d_c_m_c_d[:, 2] - 761
    cindex2 = d_c_m_c_d[:, 3]
    dindex2 = d_c_m_c_d[:, 4] - 661
    dindex1_vector = disease_hidden[dindex1]
    cindex1_vector = circ_hidden[cindex1]
    mindex1_vector = mir_hidden[mindex1]
    cindex2_vector = circ_hidden[cindex2]
    dindex2_vector = disease_hidden[dindex2]

    return dindex1_vector, cindex1_vector, mindex1_vector, cindex2_vector, dindex2_vector