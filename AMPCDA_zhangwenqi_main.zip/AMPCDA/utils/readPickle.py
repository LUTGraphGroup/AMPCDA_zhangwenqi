import pickle
import numpy as np


def extract_from_pickle(file_path):
    with open(file_path, 'rb') as file:
        data = pickle.load(file)
    node_pairs = []
    for key, value in data.items():
        node_pairs.extend(value)

    return np.array(node_pairs)


c_c_file_path = 'E:/g/data/processed/0/0-0_idx.pickle'
c_d_c_file_path = 'E:/g/data/processed/0/0-1-0_idx.pickle'
c_d_d_c_file_path = 'E:/g/data/processed/0/0-1-1-0_idx.pickle'
c_m_c_file_path = 'E:/g/data/processed/0/0-2-0_idx.pickle'

d_d_file_path = 'E:/g/data/processed/1/1-1_idx.pickle'
d_c_c_d_file_path = 'E:/g/data/processed/1/1-0-0-1_idx.pickle'
d_c_m_c_d_file_path = 'E:/g/data/processed/1/1-0-2-0-1_idx.pickle'


c_c_pairs = extract_from_pickle(c_c_file_path)
c_d_c_pairs = extract_from_pickle(c_d_c_file_path)
c_d_d_c_pairs = extract_from_pickle(c_d_d_c_file_path)
c_m_c_pairs = extract_from_pickle(c_m_c_file_path)

d_d_pairs = extract_from_pickle(d_d_file_path)
d_c_c_d_pairs = extract_from_pickle(d_c_c_d_file_path)
d_c_m_c_d_pairs = extract_from_pickle(d_c_m_c_d_file_path)