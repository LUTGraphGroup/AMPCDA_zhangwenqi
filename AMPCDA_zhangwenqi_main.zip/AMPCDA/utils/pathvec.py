from utils.initial import *
import utils.readPickle as rdp
import numpy as np
from utils.index import *
import torch
import torch.nn as nn
from sklearn.decomposition import IncrementalPCA


def cc_mp_vec(c_c, circ_hidden):
    cc_mp_vec = []
    for path in c_c:
        cindex1, cindex2 = path
        cindex1_vector = circ_hidden[cindex1]
        cindex2_vector = circ_hidden[cindex2]
        path_concat = np.concatenate([cindex1_vector, cindex2_vector])
        cc_mp_vec.append(path_concat)

    cc_mp_vec = np.array(cc_mp_vec)

    n_components = 128
    ipca = IncrementalPCA(n_components=n_components)
    batch_size = 200
    for i in range(0, 191000, batch_size):
        batch = cc_mp_vec[i:i + batch_size]
        ipca.partial_fit(batch)

    last_batch = cc_mp_vec[(191047 // batch_size) * batch_size:]
    if len(last_batch) < batch_size:
        zeros_batch = np.zeros((128 - 47, cc_mp_vec.shape[1]))
        last_batch = np.concatenate((last_batch, zeros_batch))
        ipca.partial_fit(last_batch)

    return cc_mp_vec


def cdc_mp_vec(c_d_c, circ_hidden, disease_hidden):
    cdc_mp_vec = []
    for path in c_d_c:
        cindex1, dindex1, cindex2 = path
        cindex1_vector = circ_hidden[cindex1]
        dindex1_vector = disease_hidden[dindex1 - 661]
        cindex2_vector = circ_hidden[cindex2]
        path_concat = np.concatenate([cindex1_vector, dindex1_vector, cindex2_vector])
        cdc_mp_vec.append(path_concat)

    cdc_mp_vec = np.array(cdc_mp_vec)

    n_components = 128
    ipca = IncrementalPCA(n_components=n_components)
    batch_size = 380
    for i in range(0, 13300, batch_size):
        batch = cdc_mp_vec[i:i + batch_size]
        ipca.partial_fit(batch)

    last_batch = cdc_mp_vec[(13331 // batch_size) * batch_size:]
    if len(last_batch) < batch_size:
        zeros_batch = np.zeros((128 - 31, cdc_mp_vec.shape[1]))
        last_batch = np.concatenate((last_batch, zeros_batch))
        ipca.partial_fit(last_batch)

    return cdc_mp_vec


def cddc_mp_vec(c_d_d_c, circ_hidden, disease_hidden):
    cddc_mp_vec = []
    for path in c_d_d_c:
        cindex1, dindex1, dindex2, cindex2 = path
        cindex1_vector = circ_hidden[cindex1]
        dindex1_vector = disease_hidden[dindex1 - 661]
        dindex2_vector = disease_hidden[dindex2 - 661]
        cindex2_vector = circ_hidden[cindex2]
        path_concat = np.concatenate([cindex1_vector, dindex1_vector, dindex2_vector, cindex2_vector])
        cddc_mp_vec.append(path_concat)
    cddc_mp_vec = np.array(cddc_mp_vec)

    n_components = 128
    ipca = IncrementalPCA(n_components=n_components)
    batch_size = 200
    for i in range(0, 139600, batch_size):
        batch = cddc_mp_vec[i:i + batch_size]
        ipca.partial_fit(batch)

    last_batch = cddc_mp_vec[(139667 // batch_size) * batch_size:]
    if len(last_batch) < batch_size:
        zeros_batch = np.zeros((128 - 67, cddc_mp_vec.shape[1]))
        last_batch = np.concatenate((last_batch, zeros_batch))
        ipca.partial_fit(last_batch)

    return cddc_mp_vec


def cmc_mp_vec(c_m_c, circ_hidden, mir_hidden):
    cmc_mp_vec = []
    for path in c_m_c:
        cindex1, mindex1, cindex2 = path
        cindex1_vector = circ_hidden[cindex1]
        mindex1_vector = mir_hidden[mindex1 - 761]
        cindex2_vector = circ_hidden[cindex2]
        path_concat = np.concatenate([cindex1_vector, mindex1_vector, cindex2_vector])
        cmc_mp_vec.append(path_concat)
    cmc_mp_vec = np.array(cmc_mp_vec)

    n_components = 128
    ipca = IncrementalPCA(n_components=n_components)
    batch_size = 200
    for i in range(0, 20400, batch_size):
        batch = cmc_mp_vec[i:i + batch_size]
        ipca.partial_fit(batch)

    last_batch = cmc_mp_vec[(20468 // batch_size) * batch_size:]
    if len(last_batch) < batch_size:
        zeros_batch = np.zeros((128 - 68, cmc_mp_vec.shape[1]))
        last_batch = np.concatenate((last_batch, zeros_batch))
        ipca.partial_fit(last_batch)

    return cmc_mp_vec


def dd_mp_vec(d_d, disease_hidden):
    dd_mp_vec = []
    for path in d_d:
        dindex1, dindex2 = path
        dindex1_vector = disease_hidden[dindex1 - 661]
        dindex2_vector = disease_hidden[dindex2 - 661]
        path_concat = np.concatenate([dindex1_vector, dindex2_vector])
        dd_mp_vec.append(path_concat)
    dd_mp_vec = np.array(dd_mp_vec)

    n_components = 128
    ipca = IncrementalPCA(n_components=n_components)
    batch_size = 200
    for i in range(0, 2200, batch_size):
        batch = dd_mp_vec[i:i + batch_size]
        ipca.partial_fit(batch)

    last_batch = dd_mp_vec[(2280 // batch_size) * batch_size:]
    if len(last_batch) < batch_size:
        zeros_batch = np.zeros((128 - 80, dd_mp_vec.shape[1]))
        last_batch = np.concatenate((last_batch, zeros_batch))
        ipca.partial_fit(last_batch)

        return dd_mp_vec


def dccd_mp_vec(d_c_c_d, circ_hidden, disease_hidden):
    dccd_mp_vec = []
    for path in d_c_c_d:
        dindex1, cindex1, cindex2, dindex2 = path
        dindex1_vector = disease_hidden[dindex1 - 661]
        cindex1_vector = circ_hidden[cindex1]
        cindex2_vector = circ_hidden[cindex2]
        dindex2_vector = disease_hidden[dindex2 - 661]
        path_concat = np.concatenate([dindex1_vector, cindex1_vector, cindex2_vector, dindex2_vector])
        dccd_mp_vec.append(path_concat)
    dccd_mp_vec = np.array(dccd_mp_vec)

    n_components = 128
    ipca = IncrementalPCA(n_components=n_components)
    batch_size = 450
    for i in range(0, 239850, batch_size):
        batch = dccd_mp_vec[i:i + batch_size]
        ipca.partial_fit(batch)

    last_batch = dccd_mp_vec[(239850 // batch_size) * batch_size:]
    if len(last_batch) < batch_size:
        zeros_batch = np.zeros((128 - 107, dccd_mp_vec.shape[1]))
        last_batch = np.concatenate((last_batch, zeros_batch))
        ipca.partial_fit(last_batch)

    return dccd_mp_vec


def dcmcd_mp_vec(d_c_m_c_d, circ_hidden, disease_hidden, mir_hidden):
    dcmcd_mp_vec = []
    for path in d_c_m_c_d:
        dindex1, cindex1, mindex1, cindex2, dindex2 = path
        dindex1_vector = disease_hidden[dindex1 - 661]
        cindex1_vector = circ_hidden[cindex1]
        mindex1_vector = mir_hidden[mindex1 - 761]
        cindex2_vector = circ_hidden[cindex2]
        dindex2_vector = disease_hidden[dindex2 - 661]
        path_concat = np.concatenate([dindex1_vector, cindex1_vector, mindex1_vector, cindex2_vector, dindex2_vector])
        dcmcd_mp_vec.append(path_concat)
    dcmcd_mp_vec = np.array(dcmcd_mp_vec)

    n_components = 128
    ipca = IncrementalPCA(n_components=n_components)
    batch_size = 170
    for i in range(0, 26350, batch_size):
        batch = dcmcd_mp_vec[i:i + batch_size]
        ipca.partial_fit(batch)

    last_batch = dcmcd_mp_vec[(26389 // batch_size) * batch_size:]
    if len(last_batch) < batch_size:
        zeros_batch = np.zeros((128 - 39, dcmcd_mp_vec.shape[1]))
        last_batch = np.concatenate((last_batch, zeros_batch))
        ipca.partial_fit(last_batch)

    return dcmcd_mp_vec