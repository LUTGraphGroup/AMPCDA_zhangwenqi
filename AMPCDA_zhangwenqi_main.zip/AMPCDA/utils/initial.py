import random
import dgl
import numpy as np
import networkx as nx
from scipy import sparse
from scipy.sparse import csr_matrix
from gensim.models import Word2Vec


def adj_matrix_to_graph(adj_matrix):
    return nx.from_scipy_sparse_matrix(adj_matrix)

def load_graph_data(file_path):
    data = np.load(file_path)
    adj_matrix = csr_matrix((data['data'], data['indices'], data['indptr']), shape=data['shape'])
    g = dgl.from_scipy(adj_matrix)
    return g


def random_walk(graph, start_node, walk_length):
    walk = [start_node]
    for _ in range(walk_length - 1):
        neighbors = list(graph[walk[-1]])
        if not neighbors:
            break
        walk.append(random.choice(neighbors))
    return walk


def build_corpus(graph, num_walks, walk_length):
    corpus = []
    for _ in range(num_walks):
        nodes = list(graph.nodes())
        random.shuffle(nodes)
        for node in nodes:
            walk = random_walk(graph, node, walk_length)
            corpus.append(walk)
    return corpus


def train_word2vec(corpus, vector_size=128, window=50, sg=1, epochs=100):
    model = Word2Vec(corpus, vector_size=vector_size, window=window, sg=sg, epochs=epochs)
    return model


def compute_node_features(graph_file_path='E:/e/data/processed/adjM.npz', num_walks=50, walk_length=5, vector_size=128,
                          window=50, sg=1, epochs=100):
    adj_matrix = sparse.load_npz(graph_file_path)
    G = adj_matrix_to_graph(adj_matrix)
    corpus = build_corpus(G, num_walks=num_walks, walk_length=walk_length)
    model = train_word2vec(corpus, vector_size=vector_size, window=window, sg=sg, epochs=epochs)

    node_features = []
    for node in G.nodes():
        node_features.append(model.wv[node])

    node_features = np.vstack(node_features)

    circ_hidden = node_features[0:661]
    disease_hidden = node_features[661:761]
    mir_hidden = node_features[761:2521]

    return circ_hidden, disease_hidden, mir_hidden